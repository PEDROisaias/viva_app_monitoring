
import 'package:flutter/material.dart';
import '../../../res/style/app_theme.dart';
 
/// Logo do VIVA exibida nas telas de autenticação.
/// [compact] = true → versão menor para a tela de cadastro (sem tagline).
class VivaLogo extends StatelessWidget {
  final bool compact;
 
  const VivaLogo({super.key, this.compact = false});
 
  @override
  Widget build(BuildContext context) {
    final iconSize = compact ? 48.0 : 64.0;
    final titleSize = compact ? 22.0 : 28.0;
 
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        // Ícone com glow verde
        Container(
          width: iconSize,
          height: iconSize,
          decoration: BoxDecoration(
            color: AM032Colors.statusGood.withOpacity(0.12),
            shape: BoxShape.circle,
            boxShadow: [
              BoxShadow(
                color: AM032Colors.statusGood.withOpacity(0.25),
                blurRadius: 24,
                spreadRadius: 2,
              ),
            ],
          ),
          child: Icon(
            Icons.shield_outlined,
            color: AM032Colors.statusGood,
            size: iconSize * 0.55,
          ),
        ),
 
        const SizedBox(height: 12),
 
        // Nome do app
        Text(
          'VIVA',
          style: TextStyle(
            color: AM032Colors.textPrimary,
            fontSize: titleSize,
            fontWeight: FontWeight.w900,
            letterSpacing: 6,
          ),
        ),
      ],
    );
  }
}
 